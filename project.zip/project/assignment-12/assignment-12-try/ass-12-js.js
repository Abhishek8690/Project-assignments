// let obj={
//     shrimp: 15,
//     tots: 12
// };
// document.getElementById("output").innerHTML= obj.shrimp + " " + obj.tots;
// var toarray=[];
let obj={
        shrimp: 15,
      tots: 12
     };
     let arr=[];
     for(let key in obj){
        arr.push(key);
     }
    document.getElementById("output").innerHTML=arr;