let array1 = Object.entries({ a: 1, b: 2 }) ;
let array2 = Object.entries({ shrimp: 15, tots: 12 }) ;
let array3 = Object.entries( {} );
document.getElementById('result-one').innerHTML = array1 ;
document.getElementById('result-two').innerHTML = array2 ;
document.getElementById('result-three').innerHTML = array3 ;