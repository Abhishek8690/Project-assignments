$( document ).ready( function() {
    $( "select" ).change( function( e ) {
        console.log( e.target.value );
    });
});