$ ( document ).ready ( function() {
    $('#btn-one') . click (function() {
        alert('text: ' + $('#demo').text());
    });
});