var btn = document.getElementById("btn");
btn.addEventListener("click", calc);
function calc() { 
    let num = document.getElementById("inp");
    
    let result = document.getElementById("result");
    
    if(!Number(num.value)){
        result.innerHTML = 'please enter a number';
    }
    else{
        let a = num.value;
        result.innerHTML = ++a;
    }
   // console.log(typeof Number(num));
}