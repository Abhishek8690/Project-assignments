import employeeDetail from './emp-data.json' assert{type: "json"};

let table = document.getElementById("table");
let btn1 = document.getElementById("btn1");
let employeeDetails = employeeDetail['Employee Details'];
let select = document.getElementById("select");
let card = document.getElementById("card");
//for emp table
let createTable = () => {   
    select.innerHTML = 
    `
        <select id="select-emp" class="form-select"">
            <option selected disabled hidden>Select Employee Name</option>
        </select>
    `
    let selectEmp = document.getElementById('select-emp');
    selectEmp.addEventListener("change", empDetaile);

    employeeDetails.map((emp, index) => {
        return selectEmp.innerHTML +=
        `
            <option value=${index}>${emp['Employee Name']}</option>
        `
    });
    table.innerHTML = 
    `
        <div class="table border border-2 p-0">
            <div id="thead" class="">

            </div>
            <div id="tbody">

            </div>
        </div>
    `
    let thead = document.getElementById("thead");
    let tbody = document.getElementById("tbody");
    thead.innerHTML = 
    `
        <div>
            <div id="grid-table-head" class="grid-table-head table-body-row table-columns">
            <div class="text-center table-body-cell">Sl.No</div>
            <div class="table-body-cell">Emp ID</div>
            <div class="table-body-cell">Employee Name</div>
            <div class="table-body-cell">Designation</div>
            <div class="table-body-cell">Department</div>
            <div class="table-body-cell">Active</div>
            <div class="table-body-cell">Projects</div>
            <div class="table-body-cell">Action</div>
        </div>
    `
    employeeDetails.map((emp, index) => {
        return tbody.innerHTML +=
        `
            <div class=" table-body-row table-columns">
                <div class="border border-1 table-body-cell" id="cell-one">
                    ${emp['Sl.No']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-two">
                    ${emp['Emp ID']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-three">
                    ${emp['Employee Name']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-four">
                    ${emp['Designation']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-five">
                    ${emp['Department']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-six">
                    ${emp['Active']}
                </div>
                <div class="border border-1 table-body-cell" id="cell-seven">
                    ${emp['Projects']}
                </div>
                <div class="border border-1 table-body-cell">
                    <!-- Button trigger modal -->
                    <button type="button" data-id="${index}" id="action" onClick="fnc(${index})" class="btn action" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <i class="fa-regular fa-pen-to-square"></i>
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Employee Data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div id="modal-body" class="modal-body">
                                    
                                </div>
                                <div id="modal-footer" class="modal-footer">
                                    <button type="button" id="form_button" class="btn btn-primary my-3">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `
    });
    // edit employee data
    let action = document.getElementsByClassName(`action`);
    employeeDetails.map((emp, index) => {
        let editEmpData = () => {
            if(action[`${index}`].getAttribute("data-id")==index) {
                let modalBody = document.getElementById("modal-body");
                // console.log(Object.keys(emp));
                modalBody.innerHTML = 
                `
                    <form action="" method="get">
                        <label for="emp-id" class="form-label">Emp ID</label>
                        <input type="text" class="form-control" name="emp-id" value="${emp['Emp ID']}">
                        <label for="emp-name" class="form-label">Employee Name</label>
                        <input type="text" class="form-control" name="emp-name" value="${emp['Employee Name']}">
                        <label for="designation" class="form-label">Designation</label>
                        <input type="text" class="form-control" name="designation" value="${emp['Designation']}">
                        <label for="department" class="form-label">Department</label>
                        <input type="text" class="form-control" name="department" value="${emp['Department']}">
                        <label for="active" class="form-label">Active</label>
                        <input type="text" class="form-control" name="active" value="${emp['Active']}">
                        <label for="projects" class="form-label">Projects</label>
                        <input type="text" class="form-control" name="projects" value="${emp['Projects']}">
                    </form>
                `
            }
        }
        action[`${index}`].addEventListener("click", editEmpData);
    })
    // update employee data
    let form_button = document.getElementById(`form_button`);
    let updateEmpData = () => {
        console.log(employeeDetails);
    }
    form_button.addEventListener("click", updateEmpData);
}
//to get single emp details
let empDetaile = (e) => {
    card.innerHTML = 
    `
        <div class="card" id="emp-card">
        </div>
    `
    let empcard = document.getElementById('emp-card');
    return empcard.innerHTML = `<div class="card-body">
        <h5>${employeeDetails[e.target.value]['Employee Name']}</h5>
        <p><b>Emp ID: </b>${employeeDetails[e.target.value]['Emp ID']}</p>                    
        <p><b>Designation: </b>${employeeDetails[e.target.value]['Designation']}</p>                    
        <p><b>Department: </b>${employeeDetails[e.target.value]['Department']}</p>                    
        <p><b>Active: </b>${employeeDetails[e.target.value]['Active']}</p>                    
        <p><b>Projects: </b>${employeeDetails[e.target.value]['Projects']}</p>                    
    </div>`;
}

btn1.addEventListener("click", createTable);

//*************************Additional details start****************************/
let newValues=employeeDetail["Additinal Details"];
let tabledata=document.getElementById("table");
let btn2=document.getElementById("btn2");

let additionalTable = () => {
    tabledata.innerHTML = 
    `
    <div class="p-0 border border-2 table table-striped">
        <div id="thead">

        </div>
        <div id="tbody">

        </div>
    </div>
    `
    let thead = document.getElementById("thead");
    let tbody = document.getElementById("tbody");

    thead.innerHTML=
    `
  
        <div id="grid-table-head" class="grid-table-head table-body-row text-center table-columns">
        <div class="table-body-cell">Employee Id</div>
        <div class="table-body-cell">Employee Name</div>
        <div class="table-body-cell">2022 Projects list</div>
        <div class="table-body-cell">2022 Training sessions</div>
        <div class="table-body-cell">New skilss learnt</div>
        <div class="table-body-cell">Additional Information</div>
        <div class="table-body-cell">Participation</div>
        <div class="table-body-cell">Appreciation</div>
        <div class="table-body-cell">Escalation</div>
        <div class="table-body-cell">Mentoring the juniours</div>
        <div class="table-body-cell">Learning skills</div>
        <div class="table-body-cell">Action</div>
        </div>

    `
        newValues.map((emp,index) =>{
             return tbody.innerHTML +=

        `
            <div class="table-body-row table-columns">
                <div class="border border-1 text-center table-body-cell">
                    ${emp['Emp ID']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['Employee Name']}
                </div>
                <div class="border border-1  text-center table-body-cell">
                    ${emp['2022 Projects List']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['2022 Training sessions']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['New skill Learnt']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['Addidtional Information']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['Participation']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                    ${emp['Appreciation(add email content)']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                ${emp['Escalation(Add email content)']}
                </div>
                <div class="border border-1 text-center table-body-cell">
                ${emp['Mentoring the Juniors']}
                 </div>
                 <div class="border border-1 text-center table-body-cell">
                ${emp['learning Skills']}
                 </div>
                <div class="border border-1 text-center table-body-cell">
                    <!-- Button trigger modal -->
                    <button type="button" data-id="${index}" id="action" onClick="fnc(${index})" class="btn action" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <i class="fa-regular fa-pen-to-square"></i>
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Employee Data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div id="modal-body" class="modal-body">
                                    
                                </div>
                                <div id="modal-footer" class="modal-footer">
                                    <button type="button" id="form_button" class="btn btn-primary my-3">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `
    })
}

btn2.addEventListener("click", additionalTable);
//*************************Additional detaisl end****************************/
//*************************Skill set data starts*****************************/
let skillset=employeeDetail["Skill Set Data"];
let skilltabledata=document.getElementById("table");
let btn3=document.getElementById("btn3");

let skilltable = () => {
    skilltabledata.innerHTML = 
    `
    <div class="p-0 border border-2 table table-striped">
        <div id="thead">

        </div>
        <div id="tbody">

        </div>
    </div>
    `
    let thead = document.getElementById("thead");
    let tbody = document.getElementById("tbody");
    thead.innerHTML=
    `
  
        <div id="grid-table-head" class="grid-table-head table-body-row text-center table-columns">
        <div class="table-body-cell skill-style"></div>
        <div class="table-body-cell skill-style"></div>
        <div class="table-body-cell skill-style">Score</div>
        <div class="table-body-cell skill-style">66</div>
        <div class="table-body-cell skill-style">127</div>
        <div class="table-body-cell skill-style">160</div>
        <div class="table-body-cell skill-style">214</div>
        <div class="table-body-cell skill-style">214</div>
        <div class="table-body-cell skill-style">214</div>
        <div class="table-body-cell skill-style"></div>
        </div>

    `
        skillset.map((emp,index) =>{
            
             tbody.innerHTML +=

        `
            <div class="table-body-row table-columns table-columns-skill">
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['__EMPTY']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['__EMPTY_1']}
                </div>
                <div class="border border-1  text-center table-body-cell skill-style">
                    ${emp['Score']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['66']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['127']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['160']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['214']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                    ${emp['214_1']}
                </div>
                <div class="border border-1 text-center table-body-cell skill-style">
                ${emp['214_2']}
                </div>
                <d  iv class="border border-1 text-center table-body-cell skill-style" id="last-cell">
                    <!-- Button trigger modal -->
                    <button type="button" data-id="${index}" id="action" onClick="fnc(${index})" class="btn action" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <i class="fa-regular fa-pen-to-square"></i>
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Employee Data</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div id="modal-body" class="modal-body">
                                    
                                </div>
                                <div id="modal-footer" class="modal-footer">
                                    <button type="button" id="form_button" class="btn btn-primary my-3">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `
        let lastcell=document.getElementById("last-cell");
        if(index == 0)
            {
                console.log("hello");
                lastcell.innerHTML="Action";
            }
       
    })
}

btn3.addEventListener("click", skilltable);
//*************************Skill set data ends*****************************/