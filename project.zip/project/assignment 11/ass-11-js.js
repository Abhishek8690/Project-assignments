// var btn = document.getElementById('btn');
// var result = document.getElementById('result');

// /* Display First Array Element */
// function find_first(){
//     var inputValue = document.getElementById('input-box').value;
// 	var myArray = eval ('[' + inputValue + ']');
//     console.log(myArray);
//     function isnumber( myArray )
//     {
//         if(!Number(myArray))

//         return Number(myArray);
//     }
//     if( myArray.map(isnumber(myArray)) ) {
//         document.getElementById('result').innerHTML = myArray[0];
//     }
//     else {
//         document.getElementById('result').innerHTML ='please enter a number';
//     }




    /*let array = inputValue.split(',');
    let brr = [];
    var flag = 1;
	var stringValue = 'Enter numbers only';
    for (let i = 0; i < array.length; i++){
        brr[i] = Number(array[i]);
        if (!Number(brr[i])){
            ++flag;
            document.getElementById('result').innerHTML = stringValue;
        } else if (flag <= array.length && flag != 1) {
            document.getElementById('result').innerHTML = stringValue;
		} else {
            document.getElementById('result').innerHTML = brr[0];
        }
    }*/

// }

// btn.addEventListener('click', find_first);


var btn = document.querySelector('#btn');
var result = document.querySelector('#result');
/* Display First Array Element */
function find_first(){
    var inputValue = document.querySelector('#input-box').value;
    var result = document.querySelector('#result');
    var error = document.querySelector('#error');
    var myArray = inputValue.split(',');
    myArray.map((val) => {
        newVal = Number(val);
        if(isNaN(newVal) == true) {
          error.innerHTML = 'Result: invalid input';
          result.remove();
        } 
    }) 
    document.querySelector('p').classList = 'remove-content';
    result.innerHTML= "Result: " + myArray[0];
}
btn.addEventListener('click', find_first);