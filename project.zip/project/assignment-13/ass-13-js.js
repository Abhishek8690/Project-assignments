var btn = document.getElementById( 'btn' );
function evenodd()
{
    var num = document.getElementById( 'input-box' ).value;
    num = Number( num );
    if( !Number( num )) {
            document.getElementById( 'result' ).innerHTML = 'Enter number only';
    } else {
        var sum = 0;
        while( num ) {
            const last = num % 10 ;
            sum = sum + last ;
            num = Math.floor( num / 10 );
        }
        if( sum % 2 == 0) {
            document.getElementById( 'result' ).innerHTML = ' the result is Even';
        } else {
            document.getElementById( 'result' ).innerHTML = 'The result is Odd';
            }
    }
}
btn.addEventListener( 'click' , evenodd ) ;
