const cards = ["A" , "A" , "Q" , "Q" , "6" ];
let array;
let len = cards.length;
let repeat = false;
let repeat_obj={};
console.log(cards);
for(let i = 0; i < len; i++)
{
    let count = 0;
    for( let j = 0; j < len; j++)
    {
        if( cards [i] == cards [j] && i!=j )
        {
            repeat = true;
            repeat_obj.repeat_char = cards[j];
            repeat_obj.repeat_count = ++count;
            array = Object.entries(repeat_obj);
        }
    }
}
console.log(array);
if( array.length == 1)
{
    console.log("if working");
    document.getElementById("demo").innerHTML = repeat + " " + array[0].repeat_count + " " + array[0].repeat_char;
} else {
    let max_count = array[0].repeat_count ;
    let k;
    let flag=0;
    for( k = 0 ; k < array.length ; k++ )
    {
        if(array[k].repeat_count > max_count )
        {
            max_count = array[k].repeat_count;
            flag = k ;
        }
    }
    document.getElementById("demo").innerHTML = repeat + " " + array[flag].repeat_count + " " + array[flag].repeat_char;
}
