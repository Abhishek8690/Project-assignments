let output = document.getElementById('output');
        let inp = document.getElementById('inp');
        let btn = document.getElementById('btn');
        btn.addEventListener('click', getHighestPair)
        let pokerArray = [];
        function getHighestPair() {
            let array = ( inp.value ).split( ',' );
            for( let i = 0; i < 5; i++ ) {
                for( let j = 0; j < 5; j++ ){
                    if( i !== j ) {
                        if( array[ i ] == array[ j ]){
                            pokerArray.push( array[ i ]);
                        }
                    }
                }
            }
            if( pokerArray.length == 0) {
                output.innerHTML = false;
            } else if( pokerArray.includes( 'A') || pokerArray.includes('a')) {
                output.innerHTML = "[true,'A']";
            } else if( pokerArray.includes( 'K' ) || pokerArray.includes('k')) {
                output.innerHTML = "[true,'K']";
            } else if( pokerArray.includes( 'Q' ) || pokerArray.includes('q')) {
                output.innerHTML = "[true,'Q']";
            } else if( pokerArray.includes( 'J' ) || pokerArray.includes('j')) {
                output.innerHTML = "[true,'J']";
            } else if(!Number(pokerArray)) {
                output.innerHTML="Invalid entry";
            } else {
                output.innerHTML = 'true,' + parseInt( pokerArray );
            }
        }